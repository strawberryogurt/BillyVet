<?php 
	error_reporting(E_ALL);
	ini_set('display_errors', 1)
 ?>
<?php
define("HOST","localhost");
define("USUARIO","aluno");
define("SENHA","aluno");
define("BANCO","veterinariaD");
?>