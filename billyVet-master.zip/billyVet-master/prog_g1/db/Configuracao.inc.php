<?php
define("HOST","localhost");
define("USUARIO","aluno");
define("SENHA","aluno");
define("BANCO","veterinariaD");
?>