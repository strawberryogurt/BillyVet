<?php
	session_start();
	session_destroy();
	header("Location: ../../../prog_g1/desenv/index.php");
?>




